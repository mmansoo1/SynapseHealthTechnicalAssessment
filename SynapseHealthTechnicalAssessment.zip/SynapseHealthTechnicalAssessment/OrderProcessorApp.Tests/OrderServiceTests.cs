using System.Net;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using Newtonsoft.Json.Linq;

namespace OrderProcessorApp.Tests
{
    public class OrderServiceTests
    {
        private readonly Mock<ILogger<OrderService>> _mockLogger;
        private readonly Mock<HttpMessageHandler> _mockHttpMessageHandler;
        private readonly HttpClient _httpClient;
        private readonly OrderService _orderService;

        public OrderServiceTests()
        {
            _mockLogger = new Mock<ILogger<OrderService>>();
            _mockHttpMessageHandler = new Mock<HttpMessageHandler>(MockBehavior.Strict);
            _httpClient = new HttpClient(_mockHttpMessageHandler.Object)
            {
                BaseAddress = new Uri("https://example.com")
            };

            _orderService = new OrderService(_httpClient, _mockLogger.Object);
        }

        [Fact]
        public async Task FetchMedicalEquipmentOrders_ReturnsOrders_WhenApiCallSucceeds()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK,
                    Content = new StringContent("[{\"OrderId\": \"12345\", \"Items\": []}]"),
                });


            var ordersApiUrl = "/orders";
            var result = await _orderService.FetchMedicalEquipmentOrders(ordersApiUrl);

            Assert.NotNull(result);
            Assert.Single(result);
            Assert.Equal("12345", result[0]["OrderId"].ToString());
        }

        [Fact]
        public async Task FetchMedicalEquipmentOrders_LogsError_WhenApiCallFails()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.InternalServerError,
                });

            var ordersApiUrl = "/orders";
            var result = await _orderService.FetchMedicalEquipmentOrders(ordersApiUrl);

            Assert.Empty(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Failed to fetch orders from API")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }

        [Fact]
        public async Task SendAlertMessageAsync_ReturnsTrue_WhenAlertSentSuccessfully()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK
                });

            var item = JObject.Parse("{\"Description\": \"Test Item\", \"deliveryNotification\": 1}");
            var orderId = "12345";
            var alertApiUrl = "/alerts";

            var result = await _orderService.SendAlertMessageAsync(item, orderId, alertApiUrl);

            Assert.True(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Alert sent for delivered item")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }

        [Fact]
        public async Task SendAlertMessageAsync_ReturnsFalse_WhenApiCallFails()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var item = JObject.Parse("{\"Description\": \"Test Item\", \"deliveryNotification\": 1}");
            var orderId = "12345";
            var alertApiUrl = "/alerts";

            var result = await _orderService.SendAlertMessageAsync(item, orderId, alertApiUrl);

            Assert.False(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Failed to send alert for delivered item")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }

        [Fact]
        public async Task SendAlertMessageAsync_ReturnsFalse_WhenExceptionOccurs()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ThrowsAsync(new HttpRequestException("Network error"));

            var item = JObject.Parse("{\"Description\": \"Test Item\", \"deliveryNotification\": 1}");
            var orderId = "12345";
            var alertApiUrl = "/alerts";

            var result = await _orderService.SendAlertMessageAsync(item, orderId, alertApiUrl);

            Assert.False(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("An error occurred while sending alert")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }

        [Fact]
        public async Task SendAlertAndUpdateOrderAsync_ReturnsTrue_WhenOrderIsUpdatedSuccessfully()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.OK
                });

            var order = JObject.Parse("{\"OrderId\": \"12345\"}");
            var updateApiUrl = "/update";

            var result = await _orderService.SendAlertAndUpdateOrderAsync(order, updateApiUrl);

            Assert.True(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Information,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Successfully updated order")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }

        [Fact]
        public async Task SendAlertAndUpdateOrderAsync_ReturnsFalse_WhenApiCallFails()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ReturnsAsync(new HttpResponseMessage
                {
                    StatusCode = HttpStatusCode.BadRequest
                });

            var order = JObject.Parse("{\"OrderId\": \"12345\"}");
            var updateApiUrl = "/update";

            var result = await _orderService.SendAlertAndUpdateOrderAsync(order, updateApiUrl);

            Assert.False(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("Failed to update order")),
                    null,
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }


        [Fact]
        public async Task SendAlertAndUpdateOrderAsync_ReturnsFalse_WhenExceptionOccurs()
        {
            _mockHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>()
                )
                .ThrowsAsync(new HttpRequestException("Network error"));

            var order = JObject.Parse("{\"OrderId\": \"12345\"}");
            var updateApiUrl = "/update";

            var result = await _orderService.SendAlertAndUpdateOrderAsync(order, updateApiUrl);

            Assert.False(result);
            _mockLogger.Verify(
                m => m.Log(
                    LogLevel.Error,
                    It.IsAny<EventId>(),
                    It.Is<It.IsAnyType>((v, t) => v.ToString().Contains("An error occurred while updating order")),
                    It.IsAny<Exception>(),
                    It.IsAny<Func<It.IsAnyType, Exception, string>>()),
                Times.Once
            );
        }
    }
}