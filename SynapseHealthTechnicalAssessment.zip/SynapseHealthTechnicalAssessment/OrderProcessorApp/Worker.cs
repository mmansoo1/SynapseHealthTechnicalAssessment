using Microsoft.Extensions.Options;

namespace OrderProcessorApp;

public class Worker : BackgroundService
{
    private readonly OrderService _orderService;
    private readonly ILogger<Worker> _logger;
    private readonly ApiUrls _apiUrls;

    public Worker(OrderService orderService, IOptions<ApiUrls> apiUrls, ILogger<Worker> logger)
    {
        _orderService = orderService;
        _apiUrls = apiUrls.Value;
        _logger = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("Start of App");
        _logger.LogInformation("Worker started at {Time}", DateTimeOffset.Now);

        string ordersApiUrl = _apiUrls.OrdersApi;
        string alertApiUrl = _apiUrls.AlertsApi;
        string updateApiUrl = _apiUrls.UpdatesApi;

        while (!stoppingToken.IsCancellationRequested)
        {
            var orders = await _orderService.FetchMedicalEquipmentOrders(ordersApiUrl);

            foreach (var order in orders)
            {
                await _orderService.ProcessOrderAsync(order, alertApiUrl);

                var updateSuccess = await _orderService.SendAlertAndUpdateOrderAsync(order, updateApiUrl);
                if (updateSuccess)
                {
                    _logger.LogInformation("Order updated successfully: OrderId {OrderId}", order["OrderId"]);
                    _logger.LogInformation("Results sent to relevant APIs.");
                }
                else
                {
                    _logger.LogWarning("Failed to update order: OrderId {OrderId}", order["OrderId"]);
                }

                await Task.Delay(TimeSpan.FromMinutes(5), stoppingToken);
            }
        }
    }
}
