using System.Text;
using Newtonsoft.Json.Linq;


namespace OrderProcessorApp
{
    public class OrderService
    {
        private readonly HttpClient _httpClient;
        private readonly ILogger<OrderService> _logger;

        public OrderService(HttpClient httpClient, ILogger<OrderService> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
        }

        public async Task<JObject[]> FetchMedicalEquipmentOrders(string ordersApiUrl)
        {
            var response = await _httpClient.GetAsync(ordersApiUrl);
            if (response.IsSuccessStatusCode)
            {
                var ordersData = await response.Content.ReadAsStringAsync();
                return JArray.Parse(ordersData).ToObject<JObject[]>();
            }
            _logger.LogError("Failed to fetch orders from API at {Url}.", ordersApiUrl);
            return Array.Empty<JObject>();
        }

        public async Task<bool> SendAlertMessageAsync(JToken item, string orderId, string alertApiUrl)
        {
            try
            {
                var alertData = new
                {
                    Message = $"Alert for delivered item: Order {orderId}, Item: {item["Description"]}, " +
                            $"Delivery Notifications: {item["deliveryNotification"]}"
                };
                var content = new StringContent(JObject.FromObject(alertData).ToString(), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(alertApiUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Alert sent for delivered item: {Description}", item["Description"]);
                    return true;
                }
                else
                {
                    _logger.LogError("Failed to send alert for delivered item: {Description}. Status code: {StatusCode}",
                                        item["Description"], response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                // For error handling, I can try and handle the exception in a different way instead of only logging it
                // Something like retrying if there's errors like network outages
                _logger.LogError(ex, "An error occurred while sending alert for Order {OrderId}, Item: {Description}",
                                orderId, item["Description"]);
            }

            return false;
        }


        public async Task<bool> SendAlertAndUpdateOrderAsync(JObject order, string updateApiUrl)
        {
            try
            {
                var content = new StringContent(order.ToString(), Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync(updateApiUrl, content);

                if (response.IsSuccessStatusCode)
                {
                    _logger.LogInformation("Successfully updated order: OrderId {OrderId}", order["OrderId"]);
                    return true;
                }
                else
                {
                    _logger.LogError("Failed to update order: OrderId {OrderId}. Status code: {StatusCode}",
                                    order["OrderId"], response.StatusCode);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred while updating order: OrderId {OrderId}", order["OrderId"]);
            }

            return false;
        }

        public async Task ProcessOrderAsync(JObject order, string alertApiUrl)
        {
            var items = order["Items"].ToObject<JArray>();
            foreach (var item in items)
            {
                if (IsItemDelivered(item))
                {
                    var alertSent = await SendAlertMessageAsync(item, order["OrderId"].ToString(), alertApiUrl);
                    if (alertSent)
                    {
                        IncrementDeliveryNotification(item);
                    }
                }
            }
        }

        private bool IsItemDelivered(JToken item)
        {
            return item["Status"].ToString().Equals("Delivered", StringComparison.OrdinalIgnoreCase);
        }

        private void IncrementDeliveryNotification(JToken item)
        {
            item["deliveryNotification"] = item["deliveryNotification"].Value<int>() + 1;
        }

    }
}