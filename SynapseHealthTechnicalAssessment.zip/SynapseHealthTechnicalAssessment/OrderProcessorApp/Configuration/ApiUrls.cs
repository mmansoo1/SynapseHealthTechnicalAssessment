public class ApiUrls
{
    public string OrdersApi { get; set; }
    public string AlertsApi { get; set; }
    public string UpdatesApi { get; set; }
}
