using OrderProcessorApp;

var builder = Host.CreateApplicationBuilder(args);

// Make sure appsettings.json is connected to the app
builder.Configuration.AddJsonFile("appsettings.json", optional: false, reloadOnChange: true);
builder.Services.Configure<ApiUrls>(builder.Configuration.GetSection("ApiUrls"));

builder.Services.AddHttpClient<OrderService>();
builder.Services.AddHostedService<Worker>();

var host = builder.Build();
host.Run();
